<?php
// Optional: copy to config.php only if you want a different directory.
// No absolute paths or access outside qmods.ru are needed.
return ['storage' => __DIR__ . '/_data'];
