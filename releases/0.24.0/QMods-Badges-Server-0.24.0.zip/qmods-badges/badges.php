<?php
// PHP 8.1+, curl + PDO SQLite. Never store VK access tokens or cookies.
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function reply(int $status, array $data): never { http_response_code($status); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
if (($_SERVER['HTTPS']??'')!=='on' && ($_SERVER['HTTPS']??'')!=='1') reply(400,['error'=>'https_required']);
if (($_SERVER['REQUEST_METHOD']??'')!=='POST' && ($_SERVER['REQUEST_METHOD']??'')!=='GET') reply(405,['error'=>'method']);
$config=is_file(__DIR__.'/config.php') ? (require __DIR__.'/config.php') : [];
$storage=getenv('QMODS_BADGE_STORAGE') ?: (is_array($config) ? ($config['storage']??null) : null);
if(is_string($storage) && $storage!=='' && !is_dir($storage)) @mkdir($storage,0700,true);
$doc=realpath($_SERVER['DOCUMENT_ROOT']??'');$real=is_string($storage)?realpath($storage):false;
if($doc && $real && ($real===$doc || str_starts_with($real,$doc.DIRECTORY_SEPARATOR)))reply(503,['error'=>'private_storage_required']);
if (!$storage || !is_dir($storage) || !is_writable($storage)) reply(503,['error'=>'setup_required']);
try {
 $db=new PDO('sqlite:'.$storage.'/badges.sqlite');$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$db->exec('PRAGMA busy_timeout=5000');
 $db->exec('CREATE TABLE IF NOT EXISTS badges (vk_id INTEGER PRIMARY KEY, style TEXT NOT NULL, updated INTEGER NOT NULL)');
 $db->exec('CREATE TABLE IF NOT EXISTS limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, window INTEGER NOT NULL)');
 // Coarse per-IP rate limit; addresses are hashed with a server-only random key.
 $saltFile=$storage.'/rate-secret';if(!file_exists($saltFile)){ $h=fopen($saltFile,'x');if($h){fwrite($h,random_bytes(32));fclose($h);chmod($saltFile,0600);} }
 $secret=file_get_contents($saltFile);if(!$secret)reply(503,['error'=>'setup_required']);
 $ip=hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',$secret);$bucket=intdiv(time(),60);$q=$db->prepare('INSERT INTO limits(key,count,window) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END,window=excluded.window');$q->execute([$ip,$bucket]);$q=$db->prepare('SELECT count FROM limits WHERE key=?');$q->execute([$ip]);if((int)$q->fetchColumn()>120)reply(429,['error'=>'rate_limit']);$db->prepare('DELETE FROM limits WHERE window<?')->execute([$bucket-60]);
 $method=$_SERVER['REQUEST_METHOD'];$action=$method==='GET'?($_GET['action']??'lookup'):($_POST['action']??'');
 if ($method==='GET' && $action==='health')reply(200,['schema'=>2,'ready'=>true]);
 if ($method==='GET' && $action==='lookup'){
  $raw=$_GET['ids']??'';if(!is_string($raw)||strlen($raw)>1600)reply(400,['error'=>'ids']);$ids=array_values(array_unique(array_filter(explode(',',$raw),fn($v)=>preg_match('/^[1-9][0-9]{0,12}$/D',$v))));if(count($ids)>100)reply(400,['error'=>'too_many_ids']);if(!$ids)reply(200,['schema'=>2,'users'=>[]]);$q=$db->prepare('SELECT vk_id AS id,style,updated FROM badges WHERE vk_id IN ('.implode(',',array_fill(0,count($ids),'?')).')');$q->execute($ids);reply(200,['schema'=>2,'users'=>$q->fetchAll(PDO::FETCH_ASSOC)]);
 }
 if($method!=='POST'||!in_array($action,['enroll','remove'],true))reply(400,['error'=>'action']);
 if((int)($_SERVER['CONTENT_LENGTH']??0)>12000)reply(413,['error'=>'body_too_large']);
 $token=$_POST['access_token']??'';if(!is_string($token)||strlen($token)<12||strlen($token)>8192)reply(401,['error'=>'vk_auth_required']);
 // No user_ids: users.get identifies the actual token owner, not a claimed ID.
 $ch=curl_init('https://api.vk.ru/method/users.get');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query(['access_token'=>$token,'v'=>'5.289']),CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Origin: https://m.vk.ru','Referer: https://m.vk.ru/']]);$response=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);unset($token,$_POST['access_token']);if(!is_string($response)||strlen($response)>65536||$code!==200)reply(502,['error'=>'vk_unavailable']);$json=json_decode($response,true);$id=$json['response'][0]['id']??0;if(!is_int($id)||$id<=0)reply(401,['error'=>'vk_auth_failed']);
 if($action==='remove'){$db->prepare('DELETE FROM badges WHERE vk_id=?')->execute([$id]);reply(200,['schema'=>2,'id'=>$id,'enabled'=>false]);}
 $style=$_POST['style']??'qmods';if(!in_array($style,['qmods','blue','violet','green','amber'],true))reply(400,['error'=>'style']);$db->prepare('INSERT INTO badges(vk_id,style,updated) VALUES(?,?,?) ON CONFLICT(vk_id) DO UPDATE SET style=excluded.style,updated=excluded.updated')->execute([$id,$style,time()]);reply(200,['schema'=>2,'id'=>$id,'style'=>$style,'enabled'=>true]);
} catch(Throwable $e) { reply(503,['error'=>'service_unavailable']); }
