<?php
// Copy to config.php and set an absolute writable directory OUTSIDE public_html.
return ['storage' => '/home/YOUR_ACCOUNT/private/vklite-badges'];
